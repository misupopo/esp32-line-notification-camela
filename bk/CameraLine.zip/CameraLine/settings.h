/*
 * settings.h
 * 設定情報
*/

// WiFiの資格情報 (2.4GHzのみ)
#define WIFI_SSID         "WiFiのSSIDに置き換える"
#define WIFI_PASS         "WiFiのパスワードに置き換える"

// LINEの資格情報
#define ACCESS_TOKEN      "この文字列を発行したLINEトークンで置き換えます"

// 設定情報
#define CAMERA_VFLIP      1             // カメラの設置向き（本体のM5文字の向き） 1:正常 0:逆さ
#define USE_PIR                         // タイマーを使う場合はコメントにする

#ifdef USE_PIR
  // PIR用の設定
  #define PIR_WAIT_TIME   10            // 連続送信防止用の待ち時間（秒）
  #define MESSAGE         "検知しました"  // 写真と共に送られるメッセージ
#else
  // タイマー用の設定
  #define INTERVAL_TIME   10            // 送信間隔（分）
  #define MESSAGE         "定時送信"      // 写真と共に送られるメッセージ
#endif
